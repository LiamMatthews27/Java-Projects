/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.mycput.prac7;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author matth
 */
public class runPrac7 {
    public static void main(String[] args) {
       Prac7 p7 = new Prac7 ();
       p7.setSize(600,600);
       p7.setResizable(true);
      p7.setDefaultCloseOperation(EXIT_ON_CLOSE);
      p7.setVisible(true);
    }
    
}
