
package za.ac.mycput.assignment1;

import javax.swing.JOptionPane;

/**
 *
 * @author matth
 */
public class Assignment1 {

    public static void main(String[] args) {
       
       String Eradius = JOptionPane.showInputDialog("Enter Radius" ); // enter radius 
        
        double radius = Double.parseDouble(Eradius); // takes the string and converts it into a double variable
        
        Circle circle = new Circle (radius); // Radius in brackets is asssigned to the cirlce that gets carried down to String display 
        
        String Display = "cirlce: " + "\n" + "radius:" + circle.getRadius() +"\n" + "Diameter: " + circle.getDiameter() + "\n" + "Circumferance: " + circle.getCircumference()+"\n" + 
                "area: " +circle.getArea(); // gets the method in the circle class and does the following calculation for each get method
        
        JOptionPane.showMessageDialog(null, Display); // the calculation in string display gets shown in the showmessage dialog
    }
}
