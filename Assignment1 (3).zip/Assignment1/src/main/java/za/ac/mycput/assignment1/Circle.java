/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.mycput.assignment1;

/**
 *
 * @author matth
 */
public class Circle {

    private double radius;

    public Circle() {
        this.radius = 1.0; // default value for the radius
    }

    public Circle(double radius) {
        this.radius = radius; //this radius is declared as a double variable
    }

    public double getRadius() {
        return radius; // returns the radius value
    }

    public void setRadius(double radius) {
        this.radius = radius;
    } 

    public double getDiameter() {
        return 2 * radius; // calculation for the diameter

    }

    public double getCircumference() {
        return 2 * Math.PI * radius; // calculation for the circumference
    }

    public double getArea() {
        return Math.PI * Math.pow(radius, 2); // calculation for the area 
    }

}
