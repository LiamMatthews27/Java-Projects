package za.ac.my.cput;



import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class VotingSystemDAO {

    private Connection con;

    public VotingSystemDAO() {
        con = DBConnection.derbyConnection();  // Get the connection from DBConnection
    }

    public VotingSystemDAO(Connection con) {
        this.con = con;
    }

   // Add a new vehicle to the database
public void addVehicle(Vehicles vehicle) {
    String sql = "INSERT INTO TBLVEHICLE (id, car_name, vote_num) VALUES((SELECT (MAX(id) + 1) FROM TBLVEHICLE), ?, 0)";

    try {
        PreparedStatement stmt = con.prepareStatement(sql);
        

        //stmt.setInt(1, vehicle.getId());
        stmt.setString(1, vehicle.getCar());
        //stmt.setInt(2, 0);
        stmt.executeUpdate();
        System.out.println("Vehicle added, rows affected: " + vehicle.getId() +" "+vehicle.getCar()+""+vehicle.getVoteNum());

        con.commit();
        //int ad = stmt.executeUpdate();
        //System.out.println("Vehicle added, rows affected: " + ad);

    } catch (SQLException se) {
        JOptionPane.showMessageDialog(null, "SQL Error: " + se.getMessage());
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
    }
}

    
  /*  public boolean addVehicle(String vehicleName) {
        String sql = "INSERT INTO Vehicles (VehicleName, Votes) VALUES (?, ?)";
        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, vehicleName);
            stmt.setInt(2, 0);  // Initialize votes to 0
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error adding vehicle: " + e.getMessage());
            return false;
        }
    }*/

    // Vote for a vehicle in the database
    public boolean voteForVehicle(String car) { // car id
        String sql = "UPDATE TBLVEHICLE SET vote_num = vote_num + 1 WHERE car_name = ?";
        
        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, car);
            
           stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error recording vote: " + e.getMessage());
            return false;
        }
    }

    public List<String> getVoteResults() {
        List<String> results = new ArrayList<>();
        String sql = "SELECT car_name, vote_num FROM TBLVEHICLE";
        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String vehicle = rs.getString("car_name");
                int votes = rs.getInt("vote_num");
                results.add(vehicle + ": " + votes + " votes");
            }
        } catch (SQLException e) {
            System.out.println("Error fetching vote results: " + e.getMessage());
        }
        return results;
    }
    
    public List<String> getAllVehicles() {
        List<String> results = new ArrayList<>();
        String sql = "SELECT car_name FROM TBLVEHICLE";
        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String vehicle = rs.getString("car_name");
                results.add(vehicle);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching vote results: " + e.getMessage());
        }
        return results;
    }
}

