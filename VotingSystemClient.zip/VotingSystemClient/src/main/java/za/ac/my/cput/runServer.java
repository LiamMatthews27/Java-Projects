package za.ac.my.cput;







import java.sql.Connection;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import za.ac.my.cput.VotingServerGui;

/**
 * Main class to run the voting server
 */
public class runServer {

    public static void main(String[] args) {
        // Step 1: Initialize the GUI
        VotingServerGui votingGui = new VotingServerGui();
        votingGui.setSize(700, 500);
        votingGui.setResizable(true);
        votingGui.setDefaultCloseOperation(EXIT_ON_CLOSE);
        votingGui.setVisible(true);  // Show the GUI

        // Step 2: Establish a database connection using the DBConnection class
        Connection conn = DBConnection.derbyConnection();  // Initialize the connection

        // Step 3: Initialize the DAO (Data Access Object) and pass the connection
        VotingSystemDAO dao = new VotingSystemDAO(conn);  // Pass the connection to DAO

        // Step 4: Start the server and pass the GUI and DAO to it
        VotingServer server = new VotingServer(votingGui, dao);
        server.startServer();  // Starts the server

        // Now the server is up and running and waiting for client connections
    }
}

