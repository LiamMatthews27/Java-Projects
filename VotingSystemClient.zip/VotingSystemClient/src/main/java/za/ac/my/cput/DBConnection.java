package za.ac.my.cput;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
 
/**
 *
 * @author User
 */

public class DBConnection {
    
        private static Connection con;
 public static Connection derbyConnection(){
    
      if (con == null) {
        try {
        String dbURL = "jdbc:derby://localhost:1527/Votingdb";
        String username = "administrator";
        String password = "admin";
        //specify the full pathname of the database

        System.out.println("About to get a connection....");
        con = DriverManager.getConnection(dbURL, username, password);
        System.out.println("Connection Established Successfully....");
        
    }
    catch (SQLException exception) {
        System.out.println("Error establishing connection: " + exception.getMessage());
        exception.printStackTrace();
        }
      }//
return con;
 }
    
    
}


