package za.ac.my.cput;


/**
 *
 * @author User
 */
public class Vehicles {

     
    private int id;
    private String car;
    private Integer voteNum; // check that variable type matches with db int-type

    public Vehicles(int id,String car,Integer voteNum) {
        
        this.id = id;
        this.car = car;
        this.voteNum = voteNum;

    }//end of constructor

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
      public String getCar() {
        return car;
    }

    public void setCar(String car) {
        this.car = car;
    }

  public Integer getVoteNum() {
        return voteNum;
    }

    public void setVoteNum(Integer voteNum) {
        this.voteNum = voteNum;
    }

}// end of Vehicle 
