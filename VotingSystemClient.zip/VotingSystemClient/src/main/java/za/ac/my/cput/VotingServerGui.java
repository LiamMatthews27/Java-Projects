package za.ac.my.cput;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * VotingServerGui to display voting results and allow server communication
 * with connected clients.
 */
public class VotingServerGui extends JFrame implements ActionListener {
    
    // Components
    private JButton exitBtn = new JButton("EXIT");
    private JTextArea clientTxtArea;
    private JScrollPane scrollPane;
    private JPanel topPanel, centerPanel;
    
    // Constructor to set up the server GUI
    public VotingServerGui() {
        super("Voting Server");

        // Set up the layout for the frame
        setLayout(new BorderLayout());
        
        // Initialize panels
        topPanel = new JPanel();
        centerPanel = new JPanel();

        // Create and configure text area for client communication
        clientTxtArea = new JTextArea(20, 50);
        clientTxtArea.setEditable(false);
        clientTxtArea.setLineWrap(true);
        clientTxtArea.setWrapStyleWord(true);
        
        // Make the text area auto-scroll
        JScrollPane scrollPane = new JScrollPane(clientTxtArea);
        topPanel.setLayout(new BorderLayout());
        topPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Configure exit button
        exitBtn.setForeground(Color.RED);
        exitBtn.addActionListener(this);
        centerPanel.setLayout(new BorderLayout());
        centerPanel.add(exitBtn, BorderLayout.SOUTH);

        // Add panels to the frame
        add(topPanel, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.SOUTH);

        // Frame settings
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window
        setVisible(true);
    }

    // Method to display messages from the server or clients
    public void displayMessage(String message) {
        clientTxtArea.append("From Client>> " + message + "\n");  // Append message to the text area
    }

    // Handle button actions (exit button here)
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == exitBtn) {
            System.exit(0); // Exit the application when button is pressed
        }
    }

    public static void main(String[] args) {
        // Launch the VotingServerGui
        new VotingServerGui();
    }
}
