package za.ac.my.cput;

import java.io.*;
import java.net.*;
import java.util.Arrays;
import java.util.List;

public class VotingServer {

    protected static ObjectInputStream in;
    protected static ObjectOutputStream out;
    private Socket client;
    private ServerSocket listener;
    private String request;
    private VotingServerGui gui; // GUI reference to display messages on the server GUI
    private VotingSystemDAO dao;  // Data Access Object for handling voting data

    // Constructor to initialize server with GUI and DAO
    public VotingServer(VotingServerGui gui, VotingSystemDAO dao) {
        this.gui = gui;  // Store GUI reference
        this.dao = dao;  // Store DAO reference
    }

    // Method to start the server and listen for clients
    public void startServer() {
        try {
            listener = new ServerSocket(1111);  // Set up the server socket
            System.out.println("Server is listening on port 1111");
            gui.displayMessage("Server is listening on port 1111");

            while (true) { // Keep accepting new clients
                client = listener.accept();  // Accept a client connection
                System.out.println("Client connected!");
                gui.displayMessage("Client connected!");

                getStreams();  // Set up input/output streams
                processRequests();  // Handle client requests
            }
        } catch (IOException e) {
            System.out.println("Error in startServer: " + e.toString());
            gui.displayMessage("Error in startServer: " + e.toString());
        }
    }

    // Method to set up input/output streams
    private void getStreams() throws IOException {
        try {
            out = new ObjectOutputStream(client.getOutputStream());
            in = new ObjectInputStream(client.getInputStream());
        } catch (IOException e) {
            System.out.println("Error setting up streams: " + e.toString());
            gui.displayMessage("Error setting up streams: " + e.toString());
            closeConnection(); // Ensure to close connection on failure
        }
    }

    // Method to process client requests
    public void processRequests() {
        try {
            do {
                // Read request from the client
                request = (String) in.readObject();
                System.out.println("From client>> " + request);
                gui.displayMessage("From client: " + request);

                // Handle the client request and send a response
                handleClientRequest(request);

            } while (!request.equalsIgnoreCase("TERMINATE"));  // Exit on 'TERMINATE'
        } catch (EOFException eof) {
            System.out.println("Client disconnected: " + eof.getMessage());
            gui.displayMessage("Client disconnected: " + eof.getMessage());
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error processing requests: " + e.toString());
            gui.displayMessage("Error processing requests: " + e.toString());
        } finally {
            closeConnection();  // Ensure resources are closed
        }
    }

    // Method to handle client requests (commands like ADD, VOTE, VIEW)
   private void handleClientRequest(String message) {
        try {
            String[] tokens = message.split(" ");
            String command = tokens[0];

                switch (command) {
                case "ADD":
                    if (tokens.length > 1) {
                        String vehicleName = message.substring(4);  // Extract the vehicle name

                        // Create a new Vehicles object and pass it to addVehicle
                        Vehicles vehicle = new Vehicles(0, vehicleName, 0);  // Assuming ID = 0 and votes = 0 initially
                        dao.addVehicle(vehicle);

                        sendResponse("Vehicle added successfully!");
                    } else {
                        sendResponse("Vehicle name is missing.");
                    }
                    break;

                case "VOTE":
                    if (tokens.length > 1) {
                        
                        String carName = message.substring(5);
                        try {
                            
                            boolean success = dao.voteForVehicle(carName);
                            sendResponse(success ? "Vote recorded successfully!" : "Error recording vote.");
                        } catch (NumberFormatException e) {
                            sendResponse("Invalid vote value. Must be an integer.");
                        }
                    } else {
                        sendResponse("Invalid vote command.");
                    }
                    break;

                case "VIEW":
                    List<String> results = dao.getVoteResults();  // Retrieve the results
                    if (results != null && !results.isEmpty()) {
                        String response = String.join("\n", results);  // Convert list to a string
                        sendResponse(response);  // Send the response back to the client
                    } else {
                        sendResponse("No voting data available.");
                    }
                    break;
                case "LIST":
                    List<String> vehicleList = dao.getAllVehicles();  // Retrieve the results
                    if (vehicleList != null && !vehicleList.isEmpty()) {
                        String response = String.join(";", vehicleList);  // Convert list to a string
                        sendResponse(response);  // Send the response back to the client
                    } else {
                        sendResponse("No voting data available.");
                    }
                    break;
                    
                default:
                    sendResponse("Unknown command: " + command);
                    break;
            }
        } catch (IOException e) {
            System.out.println("Error handling request: " + e.toString());
            gui.displayMessage("Error handling request: " + e.toString());
        }
    }

    // Method to send a response back to the client
    private void sendResponse(String response) throws IOException {
        out.writeObject(response);
        out.flush();  // Ensure the message is sent
    }

    // Method to close connections and streams
    private void closeConnection() {
        try {
            if (out != null) {
                out.close();  // Close the output stream
            }
            if (in != null) {
                in.close();  // Close the input stream
            }
            if (client != null) {
                client.close();  // Close the socket
            }
            System.out.println("Connection closed.");
            gui.displayMessage("Connection closed.");
        } catch (IOException e) {
            System.out.println("Error closing connection: " + e.toString());
            gui.displayMessage("Error closing connection: " + e.toString());
        }
    }
}
