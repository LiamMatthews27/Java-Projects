/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.mycput.prac62;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author matth
 */
public class Prac63 extends JFrame implements ItemListener, ActionListener {

    private JMenuBar jMB = new JMenuBar();
    private JMenu jFile = new JMenu("File");
    private JMenu jTools = new JMenu("Tools");

    private JMenuItem jNewFile = new JMenuItem("New File...");
    private JMenuItem jSave = new JMenuItem("Save");
    private JMenuItem jPrint = new JMenuItem("Print");
    private JMenuItem jExit = new JMenuItem("Exit");

    private JMenuItem jOptions = new JMenuItem("Options");
    private JMenuItem jHelp = new JMenuItem("Help");

    private JPanel topPnl = new JPanel();
    private JPanel centerPnl = new JPanel();
    private JPanel bottomPnl = new JPanel();

    private JTextField txtDisplay = new JTextField();

    private JLabel lblSelect = new JLabel("Select your team");

    JButton btnExit = new JButton("Exit");
    JButton btnSave = new JButton("Save");

    // create my JComboBox
    String[] stTeams = {"none", "Manchester-United", "Liverpool", "Manchester-City", "Arsenal", "Chelsea", "Everton", "Sunderline"};
    private JComboBox cbo = new JComboBox(stTeams);

    public Prac63() {
        super("My ComboBox");

//Menu Bar
        jMB.setBackground(Color.blue);

        topPnl.setBackground(Color.green);

        jFile.add(jNewFile);
        jFile.add(jPrint);
        jFile.add(jSave);
        jFile.add(jExit);
        jTools.add(jOptions);
        jTools.add(jHelp);

        jMB.add(jFile);
        jMB.add(jTools);
        this.setJMenuBar(jMB);

        //panel layout
        topPnl.setLayout(new GridLayout(2, 2, 5, 5));
        centerPnl.setLayout(new GridLayout(1, 1, 5, 5));
        bottomPnl.setLayout(new GridLayout(1, 2, 5, 5));

        topPnl.add(lblSelect);
        topPnl.add(cbo);
        cbo.setBackground(Color.LIGHT_GRAY);

        centerPnl.add(txtDisplay);
        txtDisplay.setBackground(Color.black);

        bottomPnl.add(btnExit);
        bottomPnl.add(btnSave);
        btnExit.setBackground(Color.red);
        btnSave.setBackground(Color.green);

        this.setLayout(new BorderLayout());
        this.add(topPnl, BorderLayout.NORTH);
        this.add(topPnl, BorderLayout.NORTH);
        this.add(centerPnl, BorderLayout.CENTER);
        this.add(bottomPnl, BorderLayout.SOUTH);

        txtDisplay = new JTextField("");
        txtDisplay.setHorizontalAlignment(JTextField.CENTER);
        txtDisplay.setForeground(Color.MAGENTA);
        this.add(txtDisplay, BorderLayout.CENTER);
        txtDisplay.setBackground(Color.white);
        txtDisplay.setFont(new Font("Verdana", Font.ROMAN_BASELINE, 24));

        btnExit.addActionListener(this);
        btnSave.addActionListener(this);
        cbo.addItemListener(this);
        jExit.addActionListener(this);
        jSave.addActionListener(this);
        jNewFile.addActionListener(this);
        jPrint.addActionListener(this);
        jOptions.addActionListener(this);
        jHelp.addActionListener(this);

    }// end of my constructor

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {
            txtDisplay.setText((String) cbo.getSelectedItem());

        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(btnExit)) {
            System.exit(0);
        } else if (e.getSource().equals(btnSave)) {
            JOptionPane.showMessageDialog(null, "Team Saved successfully ");
        } else if (e.getSource().equals(jExit)) {
            System.exit(0);
        }
            else if (e.getSource().equals(jNewFile)) {
            String fileName = JOptionPane.showInputDialog(null, "Please enter the name of the new file");
            // The showInputDialog method is asking the user to enter the name of the new file.
            // It returns the entered text, which is stored in the fileName variable.
            if (fileName != null && !fileName.isEmpty()) {
                // Checking if the fileName variable is not null and not empty
                JOptionPane.showMessageDialog(null, fileName + " has been successfully created");
            } else {
                JOptionPane.showMessageDialog(null, "No file name provided. Please try again.");
            }
            
        } else if (e.getSource().equals(jSave)) {
            JOptionPane.showMessageDialog(null, "File Saved");
        } else if (e.getSource().equals(jPrint)) {
            JOptionPane.showMessageDialog(null, "Team Documents Printed Successfully");
         
        } else if (e.getSource().equals(jOptions)) {
            JOptionPane.showMessageDialog(null, "Error occured, Please try again later");

        } else if (e.getSource().equals(jHelp)) {
    String help= JOptionPane.showInputDialog(null, "Please enter the reason for your problem");
  
    // It returns the entered text, which is stored in the reason variable.
    
    // Check if a Help was provided and it's not empty
    if (help != null && !help.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Your issue has been noted. Please wait for our agents to get back to you.");
    } else {
        JOptionPane.showMessageDialog(null, "No reason provided. Please try again.");
    }
}
    }
}
