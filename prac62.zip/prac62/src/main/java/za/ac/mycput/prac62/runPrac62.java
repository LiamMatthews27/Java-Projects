/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package za.ac.mycput.prac62;

import java.awt.Color;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author matth
 */
public class runPrac62 {

    public static void main(String[] args) {
        Prac63 p63 = new Prac63();
        p63.setVisible(true);
        p63.setSize(600, 800);
        p63.setResizable(true);
        p63.setDefaultCloseOperation(EXIT_ON_CLOSE);

    }
}
