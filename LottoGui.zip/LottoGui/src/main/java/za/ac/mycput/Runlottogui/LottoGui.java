package za.ac.mycput.Runlottogui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

/**
 * LottoGui class represents the main GUI for the Lotto application.
 * 
 * @author matth
 */
public class LottoGui extends JFrame implements ActionListener {
    
    private JPanel pnlLotto, pnlLogo, pnlLottoPlus, pnlButton, pnlTop;
    private JCheckBox checkLotto = new JCheckBox("Lotto");
    private JCheckBox checkLottoPlus = new JCheckBox("Lotto Plus");
    private JLabel center = new JLabel(new ImageIcon(""));
    private JButton btnRun, btnExit, btnClear;
    
    public LottoGui() {
        
        super("Lotto Gui");
        Border blackline = BorderFactory.createLineBorder(Color.black);
        
        ArrayList<JTextField> JTField = new ArrayList<>();
        
        pnlLotto = new JPanel();
        pnlLotto.setLayout(new GridLayout(6, 1, 5, 5));
        pnlLotto.setBorder(blackline);
        
        pnlLogo = new JPanel();
        pnlLogo.setLayout(new GridLayout(1, 3, 5, 5));
        pnlLogo.setBorder(blackline);
        pnlLogo.setSize(2, 3);
        pnlLogo.add(checkLotto);
        pnlLogo.add(checkLottoPlus);
        
        pnlButton = new JPanel();
        btnClear = new JButton("Clear");
        btnRun = new JButton("Run");
        btnExit = new JButton("Exit");
        btnClear.addActionListener(this);
        btnRun.addActionListener(this);
        btnExit.addActionListener(this);
        pnlButton.add(btnExit);
        pnlButton.add(btnRun);
        pnlButton.add(btnClear);
        
        pnlTop = new JPanel(); // Initialize pnlTop
        
        pnlLottoPlus = new JPanel();
        pnlLottoPlus.setLayout(new GridLayout(6, 1, 5, 5));
        pnlLottoPlus.setBorder(blackline);
        
        for (int i = 0; i < 6; i++) {
            JTField.add(new JTextField(3));
            JTField.get(i).setPreferredSize(new Dimension(3, 2));
            pnlLotto.add(JTField.get(i));
        }
        
        for (int i = 6; i < 12; i++) {
            JTField.add(new JTextField(3));
            JTField.get(i).setPreferredSize(new Dimension(100, 100));
            pnlLottoPlus.add(JTField.get(i));
        }
        
        add(pnlButton);
        add(pnlLotto);
        add(pnlLottoPlus);
        add(pnlTop);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(btnRun)) {
            // Handle Run button action
        } else if (e.getSource().equals(btnClear)) {
            // Handle Clear button action
        } else if (e.getSource().equals(btnExit)) {
            // Handle Exit button action
        }
    }
}
