/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.mycput.Runlottogui;

import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * Main class to run the LottoGui application.
 */
public class RunLottoGui {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LottoGui guiObject = new LottoGui();
            guiObject.setLayout(new FlowLayout()); // Set a layout manager here
            guiObject.setSize(800, 600);
            guiObject.setVisible(true);
            guiObject.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        });
    }
}
