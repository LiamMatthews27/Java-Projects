/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.mycput.mavenbdproject.Domain;

/**
 *
 * @author matth
 */
public class Subject {
    private String subCode;
    private String SubDes;

    @Override
    public String toString() {
        return "Subject{" + "subCode=" + subCode + ", SubDes=" + SubDes + '}';
    }

    public Subject(String subCode, String SubDes) {
        this.subCode = subCode;
        this.SubDes = SubDes;
    }

    public String getSubCode() {
        return subCode;
    }

    public void setSubCode(String subCode) {
        this.subCode = subCode;
    }

    public String getSubDes() {
        return SubDes;
    }

    public void setSubDes(String SubDes) {
        this.SubDes = SubDes;
    }
    
}
