package za.ac.mycput.mavenbdproject.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import static javax.swing.UIManager.get;

import za.ac.mycput.mavenbdproject.DBConnection.DBConnection;
import za.ac.mycput.mavenbdproject.Domain.Subject;

public class SubjectDAO {

    private Connection con;
    private Statement stmt;
    private PreparedStatement pstmt;

    public SubjectDAO() {
        try {
            this.con = DBConnection.derbyConnection(); // Get the connection from DBConnection
            if (this.con == null) {
                throw new SQLException("Failed to establish connection");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database connection error: " + e.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace(); // Print stack trace for debugging
        }
    }

    public Subject save(Subject subject) throws SQLException {
    String sql = "INSERT INTO Subject (subject_code, subject_description) VALUES (?, ?)";
    try (PreparedStatement pstmt = con.prepareStatement(sql)) {
        pstmt.setString(1, subject.getSubCode());
        pstmt.setString(2, subject.getSubDes());
        int rowsAffected = pstmt.executeUpdate();
        return rowsAffected > 0 ? subject : null;
    }
    }

     

    public ResultSet getAllSubjects() throws SQLException {
        String sql = "SELECT * FROM Subject";
        stmt = con.createStatement();
        return stmt.executeQuery(sql);
    }

    public boolean deleteBySubCode(String subCode) throws SQLException {
        String sql = "DELETE FROM Subject WHERE subject_code = ?";
        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, subCode);
            int rowsDeleted = pstmt.executeUpdate();
            return rowsDeleted > 0;
        } finally {
            try {
                if (pstmt != null)
                    pstmt.close();
            } catch (Exception exception) {
                // Handle exception
            }
        }
    }
}
