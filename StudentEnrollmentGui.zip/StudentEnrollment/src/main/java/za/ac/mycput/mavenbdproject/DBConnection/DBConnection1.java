/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.mycput.mavenbdproject.DBConnection;

/**
 *
 * @author matth
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection1 {

  public static Connection derbyConnection() throws SQLException {
  

    String DATABASE_URL = "jdbc:derby://localhost:1527/University";
    String username = "administrator";
    String password = "admin";

    Connection connection = DriverManager.getConnection(DATABASE_URL, username, password);
    return connection;
}

}
