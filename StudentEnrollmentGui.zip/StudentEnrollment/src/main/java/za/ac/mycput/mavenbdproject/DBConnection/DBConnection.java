package za.ac.mycput.mavenbdproject.DBConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

  public static Connection derbyConnection() throws SQLException {
    try {
        Class.forName("org.apache.derby.jdbc.ClientDriver"); // Load the driver
    } catch (ClassNotFoundException e) {
        throw new SQLException("Derby driver not found", e);
    }

    String DATABASE_URL = "jdbc:derby://localhost:1527/University";
    String username = "administrator";
    String password = "admin";

    Connection connection = DriverManager.getConnection(DATABASE_URL, username, password);
    return connection;
}

}
