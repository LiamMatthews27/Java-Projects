/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package za.ac.mycput.mavenbdproject;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import za.ac.mycput.mavenbdproject.Gui.MavenGui;

/**
 *
 * @author matth
 */
public class MavenBDProject {

    public static void main(String[] args) {
        
        MavenGui mgu = new MavenGui ();
        
        mgu.setSize(450,500);
       mgu.setVisible(true);
        mgu.setDefaultCloseOperation(EXIT_ON_CLOSE);
      
 
    }
}



