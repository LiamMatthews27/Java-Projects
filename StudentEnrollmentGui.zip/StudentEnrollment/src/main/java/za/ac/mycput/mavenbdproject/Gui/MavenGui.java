/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.mycput.mavenbdproject.Gui;

import za.ac.mycput.mavenbdproject.DAO.SubjectDAO;
import za.ac.mycput.mavenbdproject.Domain.Subject;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MavenGui extends JFrame implements ActionListener {

    private JTextField txtsubCode, txtsubDes;
    private JLabel lblsubCode, lblsubDes, lblselectSub;
    private JButton btnSave, btnCancel, btnFillComboBox, btnRead, btnDelete;
    private JComboBox<String> cboStudentEnrollment;

    private DefaultTableModel tableModel;
    private JTable enrollmentTable;
    private JScrollPane jScp;


    Subject  subject;
    SubjectDAO dao;

    public MavenGui() {
        super("Student Enrollment");
        initializeComponents();
        layoutComponents();
        registerEventHandlers();
        dao = new SubjectDAO(); // Initialize the DAO
    }

    private void initializeComponents() {

        lblsubCode = new JLabel("Subject Code");
        txtsubCode = new JTextField(15);
        lblsubDes = new JLabel("Subject Description");
        txtsubDes = new JTextField(15);
        lblselectSub = new JLabel("Select Subject");

        btnSave = new JButton("Save");
        btnCancel = new JButton("Cancel");
        btnFillComboBox = new JButton("FillComboBox");
        btnRead = new JButton("Read");
        btnDelete = new JButton("Delete");

        String[] StudentSubjects = {"Information Technology", "Accounting", "Marketing", "Jewelry & Design"};
        cboStudentEnrollment = new JComboBox<>(StudentSubjects);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Subject Code");
        tableModel.addColumn("Subject Description");

        enrollmentTable = new JTable(tableModel);
        jScp = new JScrollPane(enrollmentTable);
   
        
    }

    private void layoutComponents() {
        JPanel pnlTop = new JPanel(new GridLayout(3, 2, 5, 5));
        pnlTop.add(lblsubCode);
        pnlTop.add(txtsubCode);
        pnlTop.add(lblsubDes);
        pnlTop.add(txtsubDes);
        pnlTop.add(lblselectSub);
        pnlTop.add(cboStudentEnrollment);

        add(pnlTop, BorderLayout.NORTH);
        add(jScp, BorderLayout.CENTER);

        JPanel pnlBottom = new JPanel(new GridLayout(1, 5, 5, 5));
        pnlBottom.add(btnSave);
        pnlBottom.add(btnCancel);
        pnlBottom.add(btnFillComboBox);
        pnlBottom.add(btnRead);
        pnlBottom.add(btnDelete);
        add(pnlBottom, BorderLayout.SOUTH);

        setSize(500, 400);  // Set window size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Close operation
        setLocationRelativeTo(null);  // Center window
    }

    private void registerEventHandlers() {
        btnSave.addActionListener(this);
        btnCancel.addActionListener(this);
        btnFillComboBox.addActionListener(this);
        btnRead.addActionListener(this);
        btnDelete.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSave) {
            try {
                saveSubject();
            } catch (SQLException ex) {
                Logger.getLogger(MavenGui.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (e.getSource() == btnCancel) {
            clearFields();
        } else if (e.getSource() == btnRead) {
            loadSubjects();
        } else if (e.getSource() == btnDelete) {
            deleteSelectedSubject();
        }
    }

    private void saveSubject() throws SQLException {
        String subCode = txtsubCode.getText();
        String subDes = txtsubDes.getText();

        Subject subj = new Subject (subCode,subDes);
        
       subject = dao.save(subj);
        }

    private void clearFields() {
        txtsubCode.setText("");
        txtsubDes.setText("");
    }

    private void loadSubjects() {
        tableModel.setRowCount(0); // Clear existing data

        try {
            ResultSet resultSet = dao.getAllSubjects();
            while (resultSet.next()) {
                String subCode = resultSet.getString("subject_code");
                String subDes = resultSet.getString("subject_description");
                tableModel.addRow(new Object[]{subCode, subDes});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedSubject() {
        int selectedRow = enrollmentTable.getSelectedRow();
        if (selectedRow != -1) {
            String subCode = (String) enrollmentTable.getValueAt(selectedRow, 0);

            try {
                boolean deleted = dao.deleteBySubCode(subCode);
                if (deleted) {
                    JOptionPane.showMessageDialog(this, "Subject deleted successfully!");
                    loadSubjects(); // Reload the table with the updated data
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to delete subject");
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a subject to delete", "Warning", JOptionPane.WARNING_MESSAGE);
        }
    }

    
}