/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package za.ac.mycput.runprac8;

import java.awt.Color;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author matth
 */
public class RunPrac8 {

    public static void main(String[] args) {
        
        Prac8 p8 = new Prac8 ();
        p8.setSize(450,450);
        p8.setVisible(true);
        
        p8.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
    }
}
