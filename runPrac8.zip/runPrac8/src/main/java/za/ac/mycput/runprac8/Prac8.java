/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.mycput.runprac8;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Prac8 extends JFrame implements ActionListener {

    private JPanel topPnl = new JPanel();
    private JPanel bottomPnl = new JPanel();
    private JLabel lblNum1 = new JLabel("Number 1");
    private JLabel lblNum2 = new JLabel("Number 2");
    private JLabel lblRes = new JLabel("Results");
    private JTextField txtNum1 = new JTextField(15);
    private JTextField txtNum2 = new JTextField(15);
    private JTextField txtRes = new JTextField(15);

    private JButton btnAdd = new JButton("Add");
    private JButton btnSub = new JButton("Subtract");
    private JButton btnMul = new JButton("Multiply");
    private JButton btnDiv = new JButton("Divide");
    private JMenuBar jmBar = new JMenuBar();

    private JMenu jmOperation = new JMenu("Operations");
    private JMenu jmExit = new JMenu("Exit");

    public Prac8() {
        

        super("Prac8");
        //MenuBar
        jmBar.add(jmOperation);
        jmBar.add(jmExit);

        this.setJMenuBar(jmBar);
     
        //Top Panel 
        topPnl.setLayout(new GridLayout(1, 1, 5, 5));
        bottomPnl.setLayout(new GridLayout(1, 1, 5, 5));

        topPnl.add(lblNum1);
        topPnl.add(txtNum1);
        topPnl.add(lblNum2);
        topPnl.add(txtNum2);
        topPnl.add(lblRes);
        topPnl.add(txtRes);
        txtRes.setEditable(false);
        bottomPnl.add(btnAdd);
        bottomPnl.add(btnSub);
        bottomPnl.add(btnMul);
        bottomPnl.add(btnDiv);

        this.setLayout(new BorderLayout());
        this.add(bottomPnl, BorderLayout.SOUTH);
        this.add(topPnl, BorderLayout.NORTH);
        topPnl.setBackground(Color.blue);

        btnAdd.addActionListener(this);
        btnSub.addActionListener(this);
        btnDiv.addActionListener(this);
        btnMul.addActionListener(this);
        
        btnAdd.setBackground(Color.red);
        btnSub.setBackground(Color.GREEN);
        btnMul.setBackground(Color.YELLOW);
        btnDiv.setBackground(Color.black);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == jmExit) {
            System.exit(0);

        }

        if (e.getSource() == btnAdd) {
            try {
                int num1 = Integer.parseInt(txtNum1.getText());
                int num2 = Integer.parseInt(txtNum2.getText());
                int res = num1 + num2;
                txtRes.setText(Integer.toString(res));
            } catch (NumberFormatException ie) {

                txtRes.setText("Error" + ie.getMessage());

            }

        }

        if (e.getSource() == btnSub) {
            try {
                int num1 = Integer.parseInt(txtNum1.getText());
                int num2 = Integer.parseInt(txtNum2.getText());
                int res = num1 - num2;
                txtRes.setText(Integer.toString(res));
            } catch (NumberFormatException ie) {

                txtRes.setText("Error" + ie.getMessage());
            }
        }
        if (e.getSource() == btnDiv) {
            try {
                int num1 = Integer.parseInt(txtNum1.getText());
                int num2 = Integer.parseInt(txtNum2.getText());
                int res = num1 / num2;
                txtRes.setText(Integer.toString(res));
            } catch (NumberFormatException ie) {

                txtRes.setText("Error" + ie.getMessage());
            }
        }
        if (e.getSource() == btnMul) {
            try {
                int num1 = Integer.parseInt(txtNum1.getText());
                int num2 = Integer.parseInt(txtNum2.getText());
                int res = num1 * num2;
                txtRes.setText(Integer.toString(res));
            } catch (NumberFormatException ie) {

                txtRes.setText("Error" + ie.getMessage());
            }
        }

    }
}
