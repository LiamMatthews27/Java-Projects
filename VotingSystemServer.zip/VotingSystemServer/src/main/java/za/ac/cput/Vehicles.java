package za.ac.cput;


/**
 *
 * @author User
 */
public class Vehicles {

     
    private int id;
    private String car;
    private int voteNum; // check that variable type matches with db int-type

    public Vehicles(int id,String car,int voteNum) {
        
        this.id = id;
        this.car = car;
        this.voteNum = voteNum;

    }//end of constructor

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
      public String getCar() {
        return car;
    }

    public void setCar(String car) {
        this.car = car;
    }

  public int getVoteNum() {
        return voteNum;
    }

    public void setVoteNum(Integer voteNum) {
        this.voteNum = voteNum;
    }

    @Override
    public String toString() {
        return car ;
    }
    
    

}// end of Vehicle 

