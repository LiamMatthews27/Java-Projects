package za.ac.cput;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

/**
 *
 * @
 */
public class AddVehicleGUI extends JFrame implements ActionListener {

    private JPanel pnlT = new JPanel();
    private JPanel pnlB = new JPanel();
    private JLabel lblV = new JLabel("Vehicle: ");
    //private JTextField txtCV = new JTextField(15);
    //private JTextField txtId = new JTextField(30);
    private JTextField txtV = new JTextField(10);

    private JButton btnSubmit = new JButton("Submit");
    private JButton btnExit = new JButton("Exit");

    private VotingSystemClient client;

    public AddVehicleGUI(VotingSystemClient client1) {
        super("Add Vehicle");

        this.client = client1;  // Correctly assign the passed client object

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Panel layout with background colors
        pnlT.setLayout(new GridLayout(2, 2, 5, 5));
        pnlB.setLayout(new GridLayout(1, 3, 5, 5));

        pnlT.setBackground(Color.LIGHT_GRAY);
        pnlB.setBackground(Color.DARK_GRAY);

        // Style labels
        //lblId.setFont(new Font("Arial", Font.BOLD, 14));
        lblV.setFont(new Font("Arial", Font.BOLD, 14));
        //lblCV.setFont(new Font("Arial", Font.BOLD, 14));

        // Style buttons
        btnSubmit.setBackground(Color.GREEN);
        btnSubmit.setFont(new Font("Arial", Font.BOLD, 14));;
        btnExit.setBackground(Color.BLUE);
        btnExit.setFont(new Font("Arial", Font.BOLD, 14));

        // Add components
        //pnlT.add(lblId);
        //pnlT.add(txtId);
        pnlT.add(lblV);
        pnlT.add(txtV);
        //pnlT.add(lblCV);
        //pnlT.add(txtCV);

        pnlB.add(btnSubmit);
        pnlB.add(btnExit);

        // Panels on frame layout
        setLayout(new BorderLayout());
        add(pnlT, BorderLayout.CENTER);
        add(pnlB, BorderLayout.SOUTH);

        // Add action listeners
        btnSubmit.addActionListener(this);
        btnExit.addActionListener(this);

        // Set size and visibility
        setSize(400, 250);
        setLocationRelativeTo(null); // Center the window
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSubmit) {
            try {
               // int id = Integer.parseInt(txtId.getText());
                String car = txtV.getText();
                //Integer voteNum = Integer.parseInt(txtCV.getText());

                // Send vehicle information to server using VotingSystemClient
                client.addVehicle(car);

                JOptionPane.showMessageDialog(rootPane, "You have successfully added a vehicle", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(rootPane, "Please enter a valid number for the ID or Vote", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            if (txtV.getText().isEmpty() ) {
                JOptionPane.showMessageDialog(rootPane, "You have not entered a vehicle correctly, please check that you have filled everything", "Warning", JOptionPane.WARNING_MESSAGE);
            }
        }
        
    
        if (e.getSource() == btnExit) {
            dispose();
        }
    }
}

