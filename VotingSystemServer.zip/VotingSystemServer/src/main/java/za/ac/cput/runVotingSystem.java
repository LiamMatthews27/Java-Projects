package za.ac.cput;


//import za.ac.cput.VotingSystemGui;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;



/**
 *
 * @author User
 */
public class runVotingSystem {
    public static void main(String[] args) {
        VotingSystemGui vsg = new VotingSystemGui();
        vsg.setVisible(true);
        vsg.setSize(500,500);
        vsg.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}
