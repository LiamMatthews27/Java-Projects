package za.ac.cput;



import java.io.*;
import java.net.*;
import java.util.List;

public class VotingSystemClient {

    private Socket server;
    protected static ObjectInputStream in;
    protected static ObjectOutputStream out;

    public VotingSystemClient() {
        try {
            server = new Socket("localhost", 1111);  // Replace with correct server address and port
            getStreams();
        } catch (IOException e) {
            System.out.println("Error = " + e.toString());
        }
    }

    private void getStreams() throws IOException {
        try {
            out = new ObjectOutputStream(server.getOutputStream());
            in = new ObjectInputStream(server.getInputStream());
        } catch (IOException e) {
            System.out.println("Error = " + e.toString());
        }
    }

    // Send a vote to the server
    public void vote(String carName) {
        communicate("VOTE " + carName);
        getServerResponse();  // Fetch server response after voting
    }

    public String[] getAllVehicles(){
        communicate("LIST");
        String response = getServerResponse();
        String[] vehicles = response.split(";");
        return vehicles;
    }
    
   public String viewResults() {
    communicate("VIEW");
    return getServerResponse();  // Fetch server response for the voting results
}
   // General method to receive and return a server response
private String getServerResponse() {
    String result = null; // Variable to hold the result
    try {
        Object response = in.readObject();  // Change to Object for broader handling
        if (response != null) {
            result = response.toString(); // Store response to return
            System.out.println("Server response: \n" + result);
        } else {
            System.out.println("Received null response from server.");
        }
    } catch (EOFException eof) {
        System.out.println("EOFException: The server closed the connection unexpectedly.");
    } catch (IOException | ClassNotFoundException e) {
        System.out.println("Error reading server response: " + e.toString());
    }
    return result; // Return the response
}
    // Add a new vehicle to the server
    public void addVehicle(  String vehicleName) { // add id and vote num - parameters
        communicate("ADD " + vehicleName );
        getServerResponse();  // Fetch server response after adding the vehicle
    }

    // General method to send a message to the server
    public void communicate(String message) {
        try {
            out.writeObject(message);
            out.flush();
        } catch (IOException e) {
            System.out.println("Error = " + e.toString());
        }
    }

    // General method to receive and display a server response
  
  public void closeConnection() {
    try {
        System.out.println("Closing connection...");
        if (out != null) out.close();
        if (in != null) in.close();
        if (server != null && !server.isClosed()) server.close();  // Ensure the socket is not already closed
        System.out.println("Connection closed successfully.");
    } catch (IOException e) {
        System.out.println("Error closing connection: " + e.toString());
    }
  }
}


