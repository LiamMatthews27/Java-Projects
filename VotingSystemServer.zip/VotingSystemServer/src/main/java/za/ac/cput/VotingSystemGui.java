package za.ac.cput;

import za.ac.cput.VotingSystemClient;
import za.ac.cput.AddVehicleGUI;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

/**
 *
 * @author aimee paulus 222814969
 */
public class VotingSystemGui extends JFrame implements ActionListener {

    // Panels
    private JPanel pnlTop = new JPanel();
    private JPanel pnlMid = new JPanel();
    private JPanel pnlBottom = new JPanel();
    private JPanel pnlOptions = new JPanel(); // temp panel to add to pnlMid

    //Labels and JTextArea
    private JLabel lblCar = new JLabel("Car of the Year");
    private JLabel lblVehicle = new JLabel("Vehicle:");
    protected static JTextArea txtAreaResults = new JTextArea(10, 15); // might not be static due to btns

    //ComboBox for car options
    private JComboBox<String> cmbCars = new JComboBox<>();

    //Buttons
    private JButton btnRefresh = new JButton("Refresh");
    private JButton btnAdd = new JButton("Add");
    private JButton btnVote = new JButton("Vote");
    private JButton btnView = new JButton("View");
    private JButton btnExit = new JButton("Exit");

    private VotingSystemClient client;
    //private int voteNum = 0;

    private ArrayList<String> vehicles = new ArrayList<String>();

    public VotingSystemGui() {
        super("Voting system");

        //Panel layout
        pnlTop.setLayout(new BorderLayout());
        pnlMid.setLayout(new BorderLayout());
        pnlBottom.setLayout(new GridLayout(1, 4, 1, 1));
        pnlOptions.setLayout(new BorderLayout());

        client = new VotingSystemClient();

        this.loadVehicles();

        //add components to panels
        pnlTop.setBackground(Color.blue);
        lblCar.setForeground(Color.yellow);
        lblCar.setFont(new Font("Arial", Font.BOLD, 30)); //font family, style, and size
        lblCar.setHorizontalAlignment(SwingConstants.CENTER); // Center the label
        pnlTop.add(lblCar);

        // panel for the label and combo box
        pnlOptions.add(lblVehicle, BorderLayout.WEST); // Align label to the left
        pnlOptions.add(cmbCars, BorderLayout.CENTER);// Align combo box to the center
        pnlOptions.add(btnRefresh, BorderLayout.EAST);// Align combo box to the right

        pnlMid.add(pnlOptions, BorderLayout.NORTH); // Add pnlOptions to the NORTH of pnlMid
        txtAreaResults.setBorder(new LineBorder(Color.BLUE, 5));
        JScrollPane scrollPane = new JScrollPane(txtAreaResults);
        pnlMid.add(scrollPane, BorderLayout.SOUTH);

        //Buttons added to bottom panel
        pnlBottom.add(btnAdd);
        pnlBottom.add(btnVote);
        pnlBottom.add(btnView);
        pnlBottom.add(btnExit);

        //panels on frame layout
        setLayout(new BorderLayout());
        add(pnlTop, BorderLayout.NORTH);
        add(pnlMid, BorderLayout.CENTER);
        add(pnlBottom, BorderLayout.SOUTH);

        //addActionListeners
        btnAdd.addActionListener(this);
        btnRefresh.addActionListener(this);
        btnVote.addActionListener(this);
        btnView.addActionListener(this);
        btnExit.addActionListener(this);
    }

    private void loadVehicles() {
        cmbCars.removeAllItems(); // Clear existing items in JComboBox
        vehicles.clear(); // Clear the vehicles ArrayList if needed

        String[] vehicleList = client.getAllVehicles();

        for (String vehicle : vehicleList) {
            vehicles.add(vehicle);
            cmbCars.addItem(vehicle);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == btnAdd) {
            // Open Add Vehicle GUI
            AddVehicleGUI avg = new AddVehicleGUI(client);  // Pass client for communication
            avg.setVisible(true);
            avg.setSize(500, 150);
            avg.setResizable(false);
            avg.setDefaultCloseOperation(EXIT_ON_CLOSE);
        }

        if (e.getSource() == btnRefresh) {
            loadVehicles();
        }

        if (e.getSource() == btnVote) {
            String selectedVehicle = (String) cmbCars.getSelectedItem();
            String vote = JOptionPane.showInputDialog(this, "Enter '1' for a vote and '0' to not vote:");

            if (selectedVehicle != null && (vote.equals("1") || vote.equals("0"))) {
                // Use VotingSystemClient to send vote to the server
                client.vote(selectedVehicle);
                JOptionPane.showMessageDialog(this, "Vote updated");

                System.out.println("Vote button pressed for: " + selectedVehicle);
            } else {
                JOptionPane.showMessageDialog(this, "Please select a vehicle and enter '1' or '0' to vote.");
            }
        }

        if (e.getSource() == btnView) {
            // Use VotingSystemClient to request voting results from the server
            String results = client.viewResults(); // Get results from the server
            if (results != null) {
                txtAreaResults.setText(results); // Display results in JTextArea
            } else {
                JOptionPane.showMessageDialog(this, "No results to display.", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }

        if (e.getSource() == btnExit) {
            System.exit(0);
        }
    }
}
